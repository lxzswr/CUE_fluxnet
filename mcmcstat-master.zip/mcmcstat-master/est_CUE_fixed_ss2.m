function ss = est_CUE_fixed_ss2(kb,data)
% sum-of-squares for Himmelblau 9.9
% kb(1) is CUE, kb(2) is Q10

Aobs = data.ydata;
A = data.xdata1;
B = data.xdata2;
gR = data.xdata3;
mR0 = data.xdata4;
tau = data.xdata5;

T0 = data.xdata6 + 273.15; % T at mR0, convert to K
T = data.xdata7 + 273.15; % T

sb_const = 8.617333262.*10^(-5);

% Amodel = gR*kb(1)*A + kb(2)^((T-T0)./10).*mR0*kb(1)*B*(1-tau);

Amodel = gR*kb(1)*A + exp((-kb(2)./sb_const).*(1./T-1./T0)).*mR0*kb(1)*B*(1-tau); 
Amodel2 = (1-kb(1))*A;

ss = sum((Aobs-Amodel).^2).*0.05 + sum((Aobs-Amodel2).^2.*0.95);

%ss = sum((Aobs-Amodel2).^2);