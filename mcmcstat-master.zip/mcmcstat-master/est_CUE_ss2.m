function ss = est_CUE_ss2(k,data)
% sum-of-squares for Himmelblau 9.9

Aobs = data.ydata;
A = data.xdata1;
B = data.xdata2;

%Amodel = k(1)*k(3)*A + k(2)*k(3)*B*(1-k(4));

Amodel = k(1)*k(3)*A + k(2)*k(3)*B*(1-k(4));
Amodel2 = (1-k(3))*A;

%ss = sum((Aobs-Amodel).^2);

ss = sum((Aobs-Amodel).^2).*0.10 + sum((Aobs-Amodel2).^2.*0.90);

